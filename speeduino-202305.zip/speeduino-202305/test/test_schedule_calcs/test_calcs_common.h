#pragma once

#include <stdint.h>

void setEngineSpeed(uint16_t rpm, int16_t max_ign);