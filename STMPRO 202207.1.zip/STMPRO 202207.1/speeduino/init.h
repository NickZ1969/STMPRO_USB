#ifndef INIT_H
#define INIT_H

void initialiseAll();
void initialiseTriggers();
void setPinMapping(byte);
void changeHalfToFullSync(void);
void changeFullToHalfSync(void);

#endif